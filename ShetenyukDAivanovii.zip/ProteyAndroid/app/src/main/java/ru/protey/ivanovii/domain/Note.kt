package ru.protey.ivanovii.domain

class Note {
    var title: String
    var text: String

    constructor(title: String, text: String) {
        this.title = title
        this.text = text
    }
}